create database wipro;
use wipro;
create table employee(id int primary key,name varchar(50),age int);

insert into employee values(1,"Rakesh",51),(2,"Satyam",22);

select * from employee


/*
Username=root
Password=zxcv@0987
*/