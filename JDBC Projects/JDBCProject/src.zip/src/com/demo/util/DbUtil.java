package com.demo.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.demo.exception.EmployeeException;

public class DbUtil {
	
	public static Connection getConnection() {
		
		String url="jdbc:mysql://localhost:3306/wipro";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,"root","zxcv@0987");
			return con;
		} catch (ClassNotFoundException e) {
			throw new EmployeeException(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException(e.getMessage());
		}
		
	}

}
