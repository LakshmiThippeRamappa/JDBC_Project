package com.demo.dao;

import java.util.List;

import com.demo.model.Employee;

public interface EmployeeDao {

	List<Employee> getEmployee();
	int addEmployee(Employee employee);
}
